# Accident Detection > 2025-05-17 9:07pm
https://universe.roboflow.com/umesh-kumar-a-nwuai/accident-detection-luup4-5jnkh

Provided by a Roboflow user
License: CC BY 4.0

